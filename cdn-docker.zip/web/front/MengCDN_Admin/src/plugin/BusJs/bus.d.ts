export declare const emitter: import("mitt").Emitter<Record<import("mitt").EventType, unknown>>;
