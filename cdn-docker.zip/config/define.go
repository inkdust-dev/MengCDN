package config

type SystemConfig struct {
	PanelPort string
	AuthCode  string
}
